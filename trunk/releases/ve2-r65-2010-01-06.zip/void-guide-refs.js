var vgBase = "http://rdfs.org/ns/void-guide";
var vgREFGeneral_Dataset_Metadata = "#sec_1_1_General_Dataset_Metadata";
var vgREFCategorize_Datasets = "#sec_1_2_Categorize_Datasets";
var vgREFDescribing_Dataset_Interlink = "#sec_2_Describing_Dataset_Interlink";
var vgREFAnnouncing_the_license_of = "#sec_1_3_Announcing_the_license_of";
var vgREFVocabularies_used = "#sec_1_7_Vocabularies_used";
var vgREFSPARQL_endpoint_and_Examp = "#sec_1_6_SPARQL_endpoint_and_Examp";

